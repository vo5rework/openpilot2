Unity parity controlsAllowed latch v18 (HW2 S/X legacy)

What this overlay does:
  - Adds UNITY_PARITY_CONTROLS_ALLOWED_V18 to tesla_legacy safety.
  - Allows TX of 0x45 (STW_ACTN_RQ) and 0x659 (fake DAS status) on bus 0 for legacy + PT configs.
  - Latches controlsAllowed when AutopilotDisabled is enabled by using MAIN/CANCEL on the stalk (0x45).
  - Plumbs AutopilotDisabled from fake 0x659 into safety.

Apply on device without unzip:
  1) Copy v18_apply.py to /data/openpilot/v18_apply.py
  2) Run: python3 /data/openpilot/v18_apply.py
  3) Rebuild + flash panda/jungle, then reboot.

Verify:
  grep -R "UNITY_PARITY_CONTROLS_ALLOWED_V18" -n /data/openpilot/opendbc_repo/opendbc/safety/modes/tesla_legacy.h
